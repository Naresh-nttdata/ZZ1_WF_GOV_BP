sap.ui.define([],function(){return{callStaticAction:function(e,n){return new Promise((e,t)=>{n.execute().then(()=>{e(n)}).catch(e=>{t(e)})})}}});
//# sourceMappingURL=LogicHelper.js.map