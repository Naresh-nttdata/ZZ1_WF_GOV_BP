sap.ui.define([], function () {
    "use strict";
    return {
        CreateBusinessPartnerButton: "com.ndbs.fi.zwftogovernbp.ext.fragment.CreateBP",
        createBP:"createBP",
        Header:"Header",
        CustomerFirstName:"Customer First Name",
        CustomerLastName:"Customer Last Name",
        Name:"Name",
        NewCustomerRequest:"New Customer Request",
        UpdateCustomerRequest:"Update Customer Request",
        BusinessPartnerTypeKey:"BusinessPartnerType",
        BusinessPartnerTypeLabel:"Business Partner Type",
        BusinessPartnerCategoryKey:"BusinessPartnerCategory",
        BusinessPartnerCategoryLabel:"Business Partner Category",
        CustomerFirstNameKey:"CustomerFirstName",
        CustomerFirstNameLabel:"Customer First Name",
        CustomerLastNameKey:"CustomerLastName",
        CustomerLastNameLabel:"Customer Last Name",
        one:"1",
        two:"2",
        OrganizationNameKey:"OrganizationName",
        OrganizationNameLabel:"Organization Name",

    }
});