sap.ui.define([], function () {
    return {
 
        callStaticAction: function(oModel, oOperation) {
            return new Promise((resolve, reject) => {
                oOperation.execute()
                    .then(() => {
                        resolve(oOperation); 
                    })
                    .catch((oError) => {
                        reject(oError); 
                    });
            });
        }
    }

});