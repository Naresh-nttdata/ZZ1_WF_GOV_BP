sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("com.ndbs.fi.zwftogovernbp.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map